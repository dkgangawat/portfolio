const Certificates =[
    {
        id:1,
        img:"",
        heading:"Certificate",
        disc:"You will get certificates from E-cell IIT Roorkee"

    },
    {
        id:2,
        img:"",
        heading:"Certificate",
        disc:"You will get certificates from E-cell IIT Roorkee"

    },
    {
        id:3,
        img:"",
        heading:"Certificate",
        disc:"You will get certificates from E-cell IIT Roorkee"

    },
    {
        id:4,
        img:"",
        heading:"Certificate",
        disc:"You will get certificates from E-cell IIT Roorkee"

    },
    {
        id:5,
        img:"",
        heading:"Certificate",
        disc:"You will get certificates from E-cell IIT Roorkee"

    },
    {
        id:6,
        img:"",
        heading:"Certificate",
        disc:"You will get certificates from E-cell IIT Roorkee"

    },
]
export default Certificates