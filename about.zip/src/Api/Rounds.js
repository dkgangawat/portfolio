const Rounds = [
    {id:"Round 1",
     Round_No:"1",
     time:"12 December 2022",
     disc:" E-summit being the flagship event of E-cell. is held annually brings together the academic community, venture capitalists,new age eneterpreneurs and all those passionate about enterneurpreneurship to common grounds. E-Summit being the flagship event of Ecell, is held annually brings togther the acadmic community, venture capitalists.",
},
{id:"Round 2",
Round_No:"2",
time:"12 December 2022",
disc:" E-summit being the flagship event of E-cell. is held annually brings together the academic community, venture capitalists,new age eneterpreneurs and all those passionate about enterneurpreneurship to common grounds. E-Summit being the flagship event of Ecell, is held annually brings togther the acadmic community, venture capitalists.",
},
{id:"Round 3",
Round_No:"3",
time:"12 December 2022",
disc:" E-summit being the flagship event of E-cell. is held annually brings together the academic community, venture capitalists,new age eneterpreneurs and all those passionate about enterneurpreneurship to common grounds. E-Summit being the flagship event of Ecell, is held annually brings togther the acadmic community, venture capitalists.",
}
]
 export default Rounds